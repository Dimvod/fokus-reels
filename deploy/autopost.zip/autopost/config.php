﻿<?php
// Настройки автопубликации. Файл лежит вне папки сайта, наружу не отдаётся.
return array(
    // Долгоживущий токен Instagram (вставьте сами между кавычками, в чат не отправляйте).
    'ig_token' => '',
    // 'me' = аккаунт, которому принадлежит токен
    'ig_user_id' => 'me',
    'ig_api' => 'https://graph.instagram.com/v21.0',
    // Где лежат ролики (GitHub Pages)
    'video_base_url' => 'https://dimvod.github.io/fokus-reels',
    // Писать в группу MAX о результатах публикации
    'notify_max' => true,
);
